# ZERO FOCO para Netlify (Discord Interactions)

Este projeto troca o bot Python que precisa de conexão persistente por um bot baseado em **slash commands e interações HTTP**. O Netlify não mantém o Discord Gateway conectado 24/7; comandos slash podem funcionar sem um processo sempre ligado. Recursos dependentes de eventos contínuos (presença, mensagens comuns sem comandos, voz, etc.) não estão incluídos.

## Recursos
- `/painel`
- `/configurar_faccao`: cria cargos, categorias e canais que faltam, sem apagar canais existentes.
- `/registrar_membro`: salva ID RP e apelido no Netlify Blobs.
- `/meu_registro`: consulta o registro do usuário.
- `/advertir`: publica advertência no canal de logs.
- `/relatorio`: publica relatório no canal de logs.

## Instalação pelo celular
1. Crie um site novo no Netlify importando este projeto de um repositório Git, ou envie o ZIP se a tela do Netlify oferecer deploy manual compatível com funções. Para funções, prefira conectar um repositório Git.
2. Em **Site configuration / Environment variables**, adicione:
   - `DISCORD_TOKEN`: token do bot (Developer Portal > Bot > Reset Token/Copy).
   - `DISCORD_APP_ID`: Application ID (Developer Portal > General Information).
   - `DISCORD_PUBLIC_KEY`: Public Key (Developer Portal > General Information).
   - `DISCORD_GUILD_ID`: ID do servidor (ative Modo Desenvolvedor no Discord e copie o ID do servidor).
   - `SETUP_SECRET`: uma senha aleatória longa só para instalar os comandos.
3. Faça um novo deploy depois de salvar as variáveis.
4. No Discord Developer Portal > sua aplicação > **General Information** ou **Interactions Endpoint URL**, defina o endpoint de interações para `https://SEU-SITE.netlify.app/.netlify/functions/discord` e salve. A URL precisa ser o domínio real do seu site.
5. Registre os comandos abrindo uma vez no navegador: `https://SEU-SITE.netlify.app/.netlify/functions/register-commands?key=SUA_SETUP_SECRET`. Use exatamente o mesmo valor da variável `SETUP_SECRET`. A resposta deve ser um JSON com a lista de comandos. Depois, por segurança, troque `SETUP_SECRET` no Netlify e faça novo deploy; assim o link de configuração deixa de funcionar.
6. No Discord, confira se o bot foi convidado com scopes `bot` e `applications.commands` e permissões para ver/enviar mensagens, gerenciar canais e gerenciar cargos. O cargo do bot deve estar acima dos cargos que ele vai gerenciar.
7. Teste `/painel` no servidor.

## Segurança e limites
- Nunca mande o token do bot para ninguém nem coloque no HTML ou em repositório público.
- `configurar_faccao`, `registrar_membro`, `advertir` e `relatorio` exigem que quem executa tenha Gerenciar Servidor ou Administrador.
- A configuração não define permissões privadas avançadas; revise as permissões manualmente depois.
- O registro usa Netlify Blobs. Habilite/aceite o armazenamento do Netlify quando solicitado e confirme as condições atuais do seu plano.
- Não prometemos disponibilidade gratuita para sempre: limites e regras do Netlify podem mudar.
