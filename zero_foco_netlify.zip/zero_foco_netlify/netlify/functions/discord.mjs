import crypto from "node:crypto";
import { getStore } from "@netlify/blobs";

const API = "https://discord.com/api/v10";
const PUBLIC_KEY_PREFIX = Buffer.from("302a300506032b6570032100", "hex");
function verify(req, raw, publicKey) {
  const sig = req.headers.get("x-signature-ed25519");
  const ts = req.headers.get("x-signature-timestamp");
  if (!sig || !ts || !publicKey) return false;
  try {
    const key = crypto.createPublicKey({ key: Buffer.concat([PUBLIC_KEY_PREFIX, Buffer.from(publicKey, "hex")]), format: "der", type: "spki" });
    return crypto.verify(null, Buffer.from(ts + raw), key, Buffer.from(sig, "hex"));
  } catch { return false; }
}
const api = async (path, method = "GET", body) => {
  const r = await fetch(`${API}${path}`, { method, headers: { Authorization: `Bot ${process.env.DISCORD_TOKEN}`, "Content-Type": "application/json" }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  if (r.status === 204) return null;
  const text = await r.text();
  let data; try { data = text ? JSON.parse(text) : {}; } catch { data = { message: text }; }
  if (!r.ok) throw new Error(data.message || `Discord API respondeu ${r.status}`);
  return data;
};
const reply = async (id, token, content, ephemeral = true) => {
  const r = await fetch(`${API}/webhooks/${process.env.DISCORD_APP_ID}/${token}/messages/@original`, {
    method: "PATCH", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content, allowed_mentions: { parse: [] } })
  });
  if (!r.ok) throw new Error(`Falha ao atualizar resposta (${r.status})`);
};
const option = (interaction, name) => interaction.data.options?.find(o => o.name === name)?.value;
const memberOption = (interaction, name) => interaction.data.options?.find(o => o.name === name)?.value;
const store = () => getStore("zero-foco-data");
const safe = s => String(s ?? "").replace(/[\r\n]/g, " ").slice(0, 1500);
async function ensureTextChannel(guildId, channelName) {
  const channels = await api(`/guilds/${guildId}/channels`);
  let ch = channels.find(c => c.name === channelName && c.type === 0);
  if (!ch) ch = await api(`/guilds/${guildId}/channels`, "POST", { name: channelName, type: 0 });
  return ch;
}
async function sendChannel(channelId, content) {
  return api(`/channels/${channelId}/messages`, "POST", { content: safe(content), allowed_mentions: { parse: [] } });
}
async function configure(guildId) {
  const existing = await api(`/guilds/${guildId}/channels`);
  const roleNames = ["Líder", "Sub-Líder", "Gerente", "Recrutador", "Elite", "Membro", "Recruta"];
  const createdRoles = [];
  const roles = await api(`/guilds/${guildId}/roles`);
  for (const name of roleNames) if (!roles.some(r => r.name === name)) {
    const role = await api(`/guilds/${guildId}/roles`, "POST", { name, mentionable: false, hoist: ["Líder", "Sub-Líder"].includes(name) });
    createdRoles.push(role.name);
  }
  const categories = [
    { name: "📌・INFORMAÇÕES", channels: ["📜・regras", "📢・avisos", "📋・hierarquia"] },
    { name: "👥・GERENCIAMENTO", channels: ["📝・registros", "⚠️・advertências", "🗒️・relatórios"] },
    { name: "💬・COMUNIDADE", channels: ["💬・chat-geral", "📸・mídia"] },
    { name: "🔊・VOZ", channels: ["🔊・geral", "🎯・ação"] }
  ];
  const createdChannels = [];
  for (const cat of categories) {
    let parent = existing.find(c => c.type === 4 && c.name === cat.name);
    if (!parent) { parent = await api(`/guilds/${guildId}/channels`, "POST", { name: cat.name, type: 4 }); createdChannels.push(cat.name); }
    for (const name of cat.channels) {
      const already = existing.some(c => c.name === name);
      if (!already) { await api(`/guilds/${guildId}/channels`, "POST", { name, type: name === "🔊・geral" || name === "🎯・ação" ? 2 : 0, parent_id: parent.id }); createdChannels.push(name); }
    }
  }
  return `Configuração concluída. Cargos criados: ${createdRoles.length ? createdRoles.join(", ") : "nenhum (já existiam)"}. Canais/categorias criados: ${createdChannels.length ? createdChannels.join(", ") : "nenhum (já existiam)"}. Nada existente foi apagado. Revise manualmente as permissões dos canais privados.`;
}
export default async (req) => {
  if (req.method !== "POST") return new Response("Use POST", { status: 405 });
  const raw = await req.text();
  if (!verify(req, raw, process.env.DISCORD_PUBLIC_KEY)) return new Response("Assinatura inválida", { status: 401 });
  let interaction; try { interaction = JSON.parse(raw); } catch { return new Response("JSON inválido", { status: 400 }); }
  if (interaction.type === 1) return Response.json({ type: 1 });
  if (interaction.type !== 2) return Response.json({ type: 4, data: { content: "Tipo de interação não suportado.", flags: 64 } });
  // Acknowledge immediately through Discord's callback endpoint to meet its 3-second deadline.
  try {
    const ack = await fetch(`${API}/interactions/${interaction.id}/${interaction.token}/callback`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: 5, data: { flags: 64 } })
    });
    if (!ack.ok && ack.status !== 204) return new Response("Falha ao reconhecer interação", { status: 502 });
  } catch { return new Response("Falha ao reconhecer interação", { status: 502 }); }
  // Discord has already acknowledged the interaction; continue processing the command.
  try {
    const cmd = interaction.data.name;
    const guildId = interaction.guild_id;
    let message = "";
    if (!guildId) message = "Este comando só funciona dentro de um servidor Discord.";
    else if (cmd === "painel") message = "🤖 **ZERO FOCO — COMANDOS**\n/configurar_faccao — monta a estrutura padrão\n/registrar_membro — registra ID RP e apelido\n/meu_registro — consulta seu registro\n/advertir — registra advertência\n/relatorio — registra relatório";
    else if (cmd === "configurar_faccao") {
      const perms = BigInt(interaction.member?.permissions ?? "0");
      if ((perms & 0x20n) === 0n && (perms & 0x8n) === 0n) message = "Você precisa da permissão Gerenciar Servidor ou Administrador.";
      else message = await configure(guildId);
    } else if (cmd === "registrar_membro") {
      const perms = BigInt(interaction.member?.permissions ?? "0");
      if ((perms & 0x20n) === 0n && (perms & 0x8n) === 0n) message = "Você precisa da permissão Gerenciar Servidor ou Administrador para cadastrar membros.";
      else {
        const target = memberOption(interaction, "membro");
        const idRp = safe(option(interaction, "id_rp"));
        const apelido = safe(option(interaction, "apelido"));
        const db = store(); await db.setJSON(`registro:${guildId}:${target}`, { guildId, userId: target, idRp, apelido, criadoPor: interaction.member?.user?.id ?? interaction.user?.id, atualizadoEm: new Date().toISOString() });
        message = `Cadastro salvo: <@${target}> • ID RP: **${idRp}** • Apelido: **${apelido}**.`;
      }
    } else if (cmd === "meu_registro") {
      const uid = interaction.member?.user?.id ?? interaction.user?.id;
      const data = await store().get(`registro:${guildId}:${uid}`, { type: "json" });
      message = data ? `📋 **Seu registro ZERO FOCO**\nID RP: **${safe(data.idRp)}**\nApelido: **${safe(data.apelido)}**` : "Não encontrei um registro seu. Peça à liderança para usar `/registrar_membro`.";
    } else if (cmd === "advertir") {
      const perms = BigInt(interaction.member?.permissions ?? "0");
      if ((perms & 0x20n) === 0n && (perms & 0x8n) === 0n) message = "Você precisa da permissão Gerenciar Servidor ou Administrador.";
      else {
        const target = memberOption(interaction, "membro"); const motivo = safe(option(interaction, "motivo"));
        const channel = await ensureTextChannel(guildId, "⚠️・advertências");
        await sendChannel(channel.id, `⚠️ **ADVERTÊNCIA — ZERO FOCO**\nMembro: <@${target}>\nResponsável: <@${interaction.member?.user?.id ?? interaction.user?.id}>\nMotivo: ${motivo}\nData: ${new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}`);
        message = `Advertência registrada para <@${target}>.`;
      }
    } else if (cmd === "relatorio") {
      const perms = BigInt(interaction.member?.permissions ?? "0");
      if ((perms & 0x20n) === 0n && (perms & 0x8n) === 0n) message = "Você precisa da permissão Gerenciar Servidor ou Administrador.";
      else {
        const texto = safe(option(interaction, "texto")); const channel = await ensureTextChannel(guildId, "🗒️・relatórios");
        await sendChannel(channel.id, `🗒️ **RELATÓRIO — ZERO FOCO**\nResponsável: <@${interaction.member?.user?.id ?? interaction.user?.id}>\nData: ${new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}\n\n${texto}`);
        message = "Relatório registrado no canal de relatórios.";
      }
    } else message = "Comando desconhecido.";
    await reply(interaction.id, interaction.token, message);
  } catch (err) {
    try { await reply(interaction.id, interaction.token, `❌ Não consegui concluir o comando: ${safe(err?.message || "erro inesperado")}. Confira as permissões do bot e as variáveis de ambiente.`); } catch {}
  }
  return new Response(null, { status: 202 });
};
