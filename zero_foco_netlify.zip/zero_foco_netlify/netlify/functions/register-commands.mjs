const commands = [
  { name: "painel", description: "Mostra os comandos do ZERO FOCO" },
  { name: "configurar_faccao", description: "Cria a estrutura padrão da facção", default_member_permissions: "32" },
  { name: "registrar_membro", description: "Registra um membro da facção", options: [
    { name: "membro", description: "Membro do Discord", type: 6, required: true },
    { name: "id_rp", description: "ID do personagem no RP", type: 3, required: true },
    { name: "apelido", description: "Apelido no RP", type: 3, required: true }
  ]},
  { name: "meu_registro", description: "Consulta seu cadastro RP" },
  { name: "advertir", description: "Registra uma advertência", default_member_permissions: "32", options: [
    { name: "membro", description: "Membro advertido", type: 6, required: true },
    { name: "motivo", description: "Motivo da advertência", type: 3, required: true }
  ]},
  { name: "relatorio", description: "Registra um relatório da equipe", default_member_permissions: "32", options: [
    { name: "texto", description: "Conteúdo do relatório", type: 3, required: true }
  ]}
];
export default async (req) => {
  if (req.method !== "GET") return new Response("Use GET", { status: 405 });
  const url = new URL(req.url);
  const key = url.searchParams.get("key");
  if (!process.env.SETUP_SECRET || key !== process.env.SETUP_SECRET) return new Response("Não autorizado", { status: 401 });
  const { DISCORD_TOKEN, DISCORD_APP_ID, DISCORD_GUILD_ID } = process.env;
  if (!DISCORD_TOKEN || !DISCORD_APP_ID || !DISCORD_GUILD_ID) return Response.json({ error: "Configure DISCORD_TOKEN, DISCORD_APP_ID e DISCORD_GUILD_ID nas variáveis de ambiente." }, { status: 500 });
  const r = await fetch(`https://discord.com/api/v10/applications/${DISCORD_APP_ID}/guilds/${DISCORD_GUILD_ID}/commands`, {
    method: "PUT", headers: { Authorization: `Bot ${DISCORD_TOKEN}`, "Content-Type": "application/json" }, body: JSON.stringify(commands)
  });
  const body = await r.text();
  return new Response(body, { status: r.status, headers: { "Content-Type": "application/json" } });
};
